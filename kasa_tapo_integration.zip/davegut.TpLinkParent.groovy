/*	TP-Link TAPO plug, switches, lights, hub, and hub sensors.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
TEST Version
=================================================================================================*/
metadata {
	definition (name: "TpLink Parent", namespace: nameSpace(), author: "Dave Gutheinz", 
				singleThreaded: true,
				importUrl: "https://raw.githubusercontent.com/DaveGut/tpLink_Hubitat/main/Drivers/tpLink_parent.groovy")
	{
	}
	preferences {
		commonPreferences()
		input ("installChild", "bool", title: "Install Child Devices", defaultValue: true)
	}
}

def installed() {
	Map logData = [method: "installed", commonInstalled: commonInstalled()]
	logInfo(logData)
}

def updated() { 
	Map logData = [method: updated, installChild: installChild,
				   commonUpdated: commonUpdated()]
	if (installChild) {
		runIn(5, installChildDevices)
		pauseExecution(5000)
	}
	logInfo(logData)
}

def parse_get_device_info(result, data) {
	Map logData = [method: "parse_get_device_info", data: data]
	logDebug(logData)
}

//	===== Include Libraries =====
#include davegut.tpLinkCapEngMon
#include davegut.tpLinkCapConfiguration
#include davegut.tpLinkCommon
#include davegut.tpLinkParentCommon
#include davegut.tpLinkComms
#include davegut.tpLinkCrypto
#include davegut.tpLinkTransAes
#include davegut.tpLinkTransKlap
#include davegut.Logging
