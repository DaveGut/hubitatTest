library (
	name: "tpLinkTransAes",
	namespace: "davegut",
	author: "Compiled by Dave Gutheinz",
	description: "Handshake methods for TP-Link Integration",
	category: "utilities",
	documentationLink: ""
)

def aesHandshake(baseUrl = getDataValue("baseUrl"), devData = null) {
	Map reqData = [baseUrl: baseUrl, devData: devData]
	Map rsaKey = getRsaKey()
	def pubPem = "-----BEGIN PUBLIC KEY-----\n${rsaKey.public}-----END PUBLIC KEY-----\n"
	Map cmdBody = [ method: "handshake", params: [ key: pubPem]]
	Map reqParams = [uri: baseUrl,
					 body: new groovy.json.JsonBuilder(cmdBody).toString(),
					 requestContentType: "application/json",
					 timeout: 10]
	asynchttpPost("parseAesHandshake", reqParams, [data: reqData])
}

def parseAesHandshake(resp, data){
	Map logData = [method: "parseAesHandshake"]
	if (resp.status == 200 && resp.data != null) {
		try {
			Map reqData = [devData: data.data.devData, baseUrl: data.data.baseUrl]
			Map cmdResp =  new JsonSlurper().parseText(resp.data)
			//	cookie
			def cookieHeader = resp.headers["Set-Cookie"].toString()
			def cookie = cookieHeader.substring(cookieHeader.indexOf(":") +1, cookieHeader.indexOf(";"))
			//	keys
			byte[] privateKeyBytes = getRsaKey().private.decodeBase64()
			byte[] deviceKeyBytes = cmdResp.result.key.getBytes("UTF-8").decodeBase64()
    		Cipher instance = Cipher.getInstance("RSA/ECB/PKCS1Padding")
			instance.init(2, KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(privateKeyBytes)))
			byte[] cryptoArray = instance.doFinal(deviceKeyBytes)
			byte[] encKey = cryptoArray[0..15]
			byte[] encIv = cryptoArray[16..31]
			logData << [respStatus: "Cookies/Keys Updated", cookie: cookie,
						encKey: encKey, encIv: encIv]
			String password = encPassword
			String username = encUsername
			if (device) {
				password = parent.encPassword
				username = parent.encUsername
				device.updateSetting("cookie",[type:"password", value: cookie])
				device.updateSetting("encKey",[type:"password", value: encKey])
				device.updateSetting("encIv",[type:"password", value: encIv])
			} else {
				reqData << [cookie: cookie, encIv: encIv, encKey: encKey]
			}
			Map cmdBody = [method: "login_device",
						   params: [password: password,
									username: username],
						   requestTimeMils: 0]
			def cmdStr = JsonOutput.toJson(cmdBody).toString()
			Map reqBody = [method: "securePassthrough",
						   params: [request: aesEncrypt(cmdStr, encKey, encIv)]]
			Map reqParams = [uri: reqData.baseUrl,
							  body: reqBody,
							  timeout:10, 
							  headers: ["Cookie": cookie],
							  contentType: "application/json",
							  requestContentType: "application/json"]
			asynchttpPost("parseAesLogin", reqParams, [data: reqData])
			logDebug(logData)
		} catch (err) {
			logData << [respStatus: "ERROR parsing HTTP resp.data",
						respData: resp.data, error: err]
			logWarn(logData)
		}
	} else {
		logData << [respStatus: "ERROR in HTTP response", resp: resp.properties]
		logWarn(logData)
	}
}

def parseAesLogin(resp, data) {
	if (device) {
		Map logData = [method: "parseAesLogin"]
		if (resp.status == 200) {
			if (resp.json.error_code == 0) {
				try {
					byte[] encKey = new JsonSlurper().parseText(encKey)
					byte[] encIv = new JsonSlurper().parseText(encIv)
					def clearResp = aesDecrypt(resp.json.result.response, encKey, encIv)
					Map cmdResp = new JsonSlurper().parseText(clearResp)
					if (cmdResp.error_code == 0) {
						def token = cmdResp.result.token
						logData << [respStatus: "OK", token: token]
						device.updateSetting("token",[type:"password", value: token])
						setCommsError(200)
						logDebug(logData)
					} else {
						logData << [respStatus: "ERROR code in cmdResp", 
									error_code: cmdResp.error_code,
									check: "cryptoArray, credentials", data: cmdResp]
						logInfo(logData)
					}
				} catch (err) {
					logData << [respStatus: "ERROR parsing respJson", respJson: resp.json,
								error: err]
					logInfo(logData)
				}
			} else {
				logData << [respStatus: "ERROR code in resp.json", errorCode: resp.json.error_code,
							respJson: resp.json]
				logInfo(logData)
			}
		} else {
			logData << [respStatus: "ERROR in HTTP response", respStatus: resp.status, data: resp.properties]
			logInfo(logData)
		}
	} else {
		//	Code used in application only.
		getAesToken(resp, data.data)
	}
}

def getAesParams(cmdBody) {
	byte[] encKey = new JsonSlurper().parseText(encKey)
	byte[] encIv = new JsonSlurper().parseText(encIv)
	def cmdStr = JsonOutput.toJson(cmdBody).toString()
	Map reqBody = [method: "securePassthrough",
				   params: [request: aesEncrypt(cmdStr, encKey, encIv)]]
	Map reqParams = [uri: "${getDataValue("baseUrl")}?token=${token}",
					 body: new groovy.json.JsonBuilder(reqBody).toString(),
					 contentType: "application/json",
					 requestContentType: "application/json",
					 timeout: 10,
					 ignoreSSLIssues: true,
					 headers: ["Cookie": cookie]]
	return reqParams
}

def parseAesData(resp, data) {
	Map parseData = [parseMethod: "parseAesData", sourceMethod: data.data]
	try {
		byte[] encKey = new JsonSlurper().parseText(encKey)
		byte[] encIv = new JsonSlurper().parseText(encIv)
		Map cmdResp = new JsonSlurper().parseText(aesDecrypt(resp.json.result.response,
														 encKey, encIv))
		parseData << [cryptoStatus: "OK", cmdResp: cmdResp]
	} catch (err) {
		parseData << [cryptoStatus: "decryptDataError", error: err, dataLength: resp.data.length()]
	}
	return parseData
}

def getRsaKey() {
	return [public: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDGr/mHBK8aqx7UAS+g+TuAvE3J2DdwsqRn9MmAkjPGNon1ZlwM6nLQHfJHebdohyVqkNWaCECGXnftnlC8CM2c/RujvCrStRA0lVD+jixO9QJ9PcYTa07Z1FuEze7Q5OIa6pEoPxomrjxzVlUWLDXt901qCdn3/zRZpBdpXzVZtQIDAQAB",
			private: "MIICeAIBADANBgkqhkiG9w0BAQEFAASCAmIwggJeAgEAAoGBAMav+YcErxqrHtQBL6D5O4C8TcnYN3CypGf0yYCSM8Y2ifVmXAzqctAd8kd5t2iHJWqQ1ZoIQIZed+2eULwIzZz9G6O8KtK1EDSVUP6OLE71An09xhNrTtnUW4TN7tDk4hrqkSg/GiauPHNWVRYsNe33TWoJ2ff/NFmkF2lfNVm1AgMBAAECgYEAocxCHmKBGe2KAEkq+SKdAxvVGO77TsobOhDMWug0Q1C8jduaUGZHsxT/7JbA9d1AagSh/XqE2Sdq8FUBF+7vSFzozBHyGkrX1iKURpQFEQM2j9JgUCucEavnxvCqDYpscyNRAgqz9jdh+BjEMcKAG7o68bOw41ZC+JyYR41xSe0CQQD1os71NcZiMVqYcBud6fTYFHZz3HBNcbzOk+RpIHyi8aF3zIqPKIAh2pO4s7vJgrMZTc2wkIe0ZnUrm0oaC//jAkEAzxIPW1mWd3+KE3gpgyX0cFkZsDmlIbWojUIbyz8NgeUglr+BczARG4ITrTV4fxkGwNI4EZxBT8vXDSIXJ8NDhwJBAIiKndx0rfg7Uw7VkqRvPqk2hrnU2aBTDw8N6rP9WQsCoi0DyCnX65Hl/KN5VXOocYIpW6NAVA8VvSAmTES6Ut0CQQCX20jD13mPfUsHaDIZafZPhiheoofFpvFLVtYHQeBoCF7T7vHCRdfl8oj3l6UcoH/hXMmdsJf9KyI1EXElyf91AkAvLfmAS2UvUnhX4qyFioitjxwWawSnf+CewN8LDbH7m5JVXJEh3hqp+aLHg1EaW4wJtkoKLCF+DeVIgbSvOLJw"]
}
