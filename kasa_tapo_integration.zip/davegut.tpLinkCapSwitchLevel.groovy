library (
	name: "tpLinkCapSwitchLevel",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Hubitat capability Switch Level and Change Level methods",
	category: "utilities",
	documentationLink: ""
)

capability "Switch Level"
capability "Change Level"

def setLevel(level, transTime=0) {
	state.eventType = "digital"
	Map logData = [method: "setLevel", level: level, transTime: transTime]
	// range checks
	if (level > 100 || level < 0 || level == null) {
		logData << [error: "level out of range"]
		logWarn(logData)
		return
	}
	if (level == 0) {
		off()
	} else if (transTime > 0) {
		execLevelTrans(level, transTime)
	} else {
		List requests = [[method: "set_device_info",
						  params: [brightness: level]]]
		requests << [method: "get_device_info"]
		sendDevCmd(requests, "setLevel", "parseUpdates")
	}
	logDebug(logData)
}

def execLevelTrans(targetLevel, transTime) {
	Map logData = [method: "execLevelTrans", targetLevel: targetLevel,
				   transTime: transTime]
	def currLevel = device.currentValue("level")
	logData << [currLevel: currLevel]
	if (device.currentValue("switch") == "off") { currLevel = 0 }
	if (targetLevel == currLevel) {
		logData << [ERROR:  "no level change"]
		logWarn(logData)
		return
	}
	if (transTime > 10) {
		transTime = 10
		logData << [transTimeChange: transTime]
	}
	def levelChange = targetLevel - currLevel
	//	Calculate deltaLevel based on 250ms interval.  Convert to next integer.
	def deltaLevel = (0.99 + (levelChange / (4 * transTime))).toInteger()	//	next greater integer.
	if(levelChange < 0) {
		deltaLevel = (-0.99 + (levelChange / (4 * transTime))).toInteger()
	}
	//	calculate total increments based on level change and delta level
	def incrs = (0.99 + (levelChange / deltaLevel)).toInteger()
	//	calculate cmdDelay based on 
	def cmdDelay = (1000 * transTime / incrs).toInteger() - 10
	logData << [incrs: incrs, cmdDelay: cmdDelay]
	def startTime = now()
	def newLevel = currLevel
	if (targetLevel < currLevel) {
		while(targetLevel < newLevel) {
			newLevel = setNewLevel(targetLevel, currLevel, newLevel, deltaLevel)
			sendTransCmd(newLevel)
			pauseExecution(cmdDelay)
		}		
	} else if (targetLevel > currLevel) {
		while(targetLevel > newLevel) {
			newLevel = setNewLevel(targetLevel, currLevel, newLevel, deltaLevel)
			sendTransCmd(newLevel)
			pauseExecution(cmdDelay)
		}
	}
	def execTime = now() - startTime
	runIn(3, setLevel, [data: targetLevel])
	logData << [execTime: execTime]
	logDebug(logData)
}

def setNewLevel(targetLevel, currLevel, newLevel, deltaLevel) {
	newLevel += deltaLevel
	if ((targetLevel < currLevel && newLevel < targetLevel) ||
		(targetLevel > currLevel && newLevel > targetLevel)) {
		newLevel = targetLevel
	}
	return newLevel
}

def sendTransCmd(newLevel) {
		List requests = [[method: "set_device_info",
						  params: [
							  brightness: newLevel]]]
			sendDevCmd(requests, "sendTransCmd", "")
}

def startLevelChange(direction) {
	logDebug("startLevelChange: [level: ${device.currentValue("level")}, direction: ${direction}]")
	if (direction == "up") { levelUp() }
	else { levelDown() }
}

def stopLevelChange() {
	logDebug("stopLevelChange: [level: ${device.currentValue("level")}]")
	unschedule(levelUp)
	unschedule(levelDown)
}

def levelUp() {
	def curLevel = device.currentValue("level").toInteger()
	if (curLevel != 100) {
		def newLevel = curLevel + 4
		if (newLevel > 100) { newLevel = 100 }
		setLevel(newLevel)
		runIn(1, levelUp)
	}
}

def levelDown() {
	def curLevel = device.currentValue("level").toInteger()
	if (device.currentValue("switch") == "on") {
		def newLevel = curLevel - 4
		if (newLevel <= 0) { off() }
		else {
			setLevel(newLevel)
			runIn(1, levelDown)
		}
	}
}

def levelParse(result) {
	Map logData = [method: "levelParse"]
	if (device.currentValue("level") != result.brightness) {
		sendEvent(name: "level", value: result.brightness, type: state.eventType)
	}
	state.eventType = "physical"
	logData << [level: result.brightness]
	logDebug(logData)
}
