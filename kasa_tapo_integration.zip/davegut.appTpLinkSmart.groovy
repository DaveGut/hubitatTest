library (
	name: "appTpLinkSmart",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Discovery library for Application support the Tapo protocol devices.",
	category: "utilities",
	documentationLink: ""
)
import org.json.JSONObject
import groovy.json.JsonOutput
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def createTpLinkCreds() {
	Map SMARTCredData = [u: userName, p: userPassword]
	//	User Creds (username/password hashed)
	String encUsername = mdEncode("SHA-1", userName.bytes).encodeHex().encodeAsBase64().toString()
	app?.updateSetting("encUsername", [type: "string", value: encUsername])
	SMARTCredData << [encUsername: encUsername]
	String encPassword = userPassword.trim().bytes.encodeBase64().toString()
	app?.updateSetting("encPassword", [type: "string", value: encPassword])
	SMARTCredData << [encPassword: encPassword]
	//	KLAP Local Hash
	byte[] userHashByte = mdEncode("SHA-1", encodeUtf8(userName).getBytes())
	byte[] passwordHashByte = mdEncode("SHA-1", encodeUtf8(userPassword.trim()).getBytes())
	byte[] authHashByte = [userHashByte, passwordHashByte].flatten()
	String authHash = mdEncode("SHA-256", authHashByte).encodeBase64().toString()
	app?.updateSetting("localHash", [type: "string", value: authHash])
	SMARTCredData << [localHash: localHash]
	logDebug(SMARTCredData)
	return [SMARTDevCreds: SMARTCredData]
}

def findTpLinkDevices(action, timeout = 10) {
	Map logData = [method: "findTpLinkDevices", action: action, timeOut: timeout]
	def start = state.hostArray.min().toInteger()
	def finish = state.hostArray.max().toInteger() + 1
	logData << [hostArray: state.hostArray, pollSegments: state.segArray]
	List deviceIPs = []
	state.segArray.each {
		def pollSegment = it.trim()
		logData << [pollSegment: pollSegment]
		for(int i = start; i < finish; i++) {
			deviceIPs.add("${pollSegment}.${i.toString()}")
		}
		def cmdData = "0200000101e51100095c11706d6f58577b22706172616d73223a7b227273615f6b6579223a222d2d2d2d2d424547494e205055424c4943204b45592d2d2d2d2d5c6e4d494942496a414e42676b71686b6947397730424151454641414f43415138414d49494243674b43415145416d684655445279687367797073467936576c4d385c6e54646154397a61586133586a3042712f4d6f484971696d586e2b736b4e48584d525a6550564134627532416257386d79744a5033445073665173795679536e355c6e6f425841674d303149674d4f46736350316258367679784d523871614b33746e466361665a4653684d79536e31752f564f2f47474f795436507459716f384e315c6e44714d77373563334b5a4952387a4c71516f744657747239543337536e50754a7051555a7055376679574b676377716e7338785a657a78734e6a6465534171765c6e3167574e75436a5356686d437931564d49514942576d616a37414c47544971596a5442376d645348562f2b614a32564467424c6d7770344c7131664c4f6a466f5c6e33737241683144744a6b537376376a624f584d51695666453873764b6877586177717661546b5658382f7a4f44592b2f64684f5374694a4e6c466556636c35585c6e4a514944415141425c6e2d2d2d2d2d454e44205055424c4943204b45592d2d2d2d2d5c6e227d7d"
		logData << [pass1: "port 20002"]
		atomicState.finding = true
		//	Send a quick cmd to wake up any "sleeping" device
		sendLanCmd(deviceIPs.join(','), "20002", cmdData, "nullParse", 1)
		pauseExecution(2000)
		sendLanCmd(deviceIPs.join(','), "20002", cmdData, action, timeout)
		runIn(timeout + 5, udpTimeout)
		pauseExecution(timeout * 1000)
		def await = waitFor(30)
//		logData << [pass2: "port 20004"]
//		sendLanCmd(deviceIPs.join(','), "20004", cmdData, "nullParse", 1)
//		pauseExecution(2000)
//		atomicState.finding = true
//		sendLanCmd(deviceIPs.join(','), "20004", cmdData, action, timeout)
//		runIn(timeout + 5, udpTimeout)
//		pauseExecution(timeout * 1000)
//		await = waitFor(30)
	}
	pauseExecution(5000)
	logInfo(logData)
	state.tpLinkChecked = true
	runIn(570, resetTpLinkChecked)
	return
}

def udpTimeout() {
	Map logData = [method: "udpTimeout", status: "no devices found", error: "udpTimeout"]
	logDebug(logData)
	atomicState.finding = false
}

def waitFor(secs) {
	int i = 0
	for(i = 0; i < secs; i+=1) {
		if (atomicState.finding == false) { i = secs } 
		else { pauseExecution(1000) }
	}
	return
}

def nullParse(response) {}

def getTpLinkLanData(response) {
	Map logData = [method: "getTpLinkLanData", 
				   action: "Completed LAN Discovery",
				   smartDevicesFound: response.size()]
	logInfo(logData)
	unschedule("udpTimeout")
	List discData = []
	if (response instanceof Map) {
		Map devData = getDiscData(response)
		if (devData.status == "OK") {
			discData << devData
		}
	} else {
		response.each {
			Map devData = getDiscData(it)
			if (devData.status == "OK" && !discData.toString().contains(devData.dni)) {
				discData << devData
			}
		}
	}
	getAllTpLinkDeviceData(discData)
}

def getDiscData(response) {
	Map devData = [:]
	Map payload = [:]
	try {
		def respData = parseLanMessage(response.description)
		if (respData.type == "LAN_TYPE_UDPCLIENT") {
			byte[] payloadByte = hubitat.helper.HexUtils.hexStringToByteArray(respData.payload.drop(32)) 
			String payloadString = new String(payloadByte)
			if (payloadString.length() > 1007) {
				payloadString = stringCorrect(payloadString)
			}
			payload = new JsonSlurper().parseText(payloadString).result
		}
	} catch (err) {
		devData << [status: "INVALID", respData: repsData, error: err]
		logWarn(devData)
		return devData
	}
	String devType = payload.device_type
	String model = payload.device_model
	String devIp = payload.ip
	String protocol = payload.mgt_encrypt_schm.encrypt_type
	if (isTypeSup(devType) == false) {
		Map unsupData = ["<b>${model}</b>": [type: devType, ip: devIp, protocol: protocol]]
		logInfo([getDiscData: [notSupported: unsupData]])
		atomicState.unsupported << ["<b>${model}</b>": [ip: ip, protocol: protocol]]
	} else {
		String dni = payload.mac.replaceAll("-", "")
		String port = payload.mgt_encrypt_schm.http_port
		String httpStr = "http://"
		String httpPath = "/app"
		if (payload.mgt_encrypt_schm.is_support_https) { httpStr = "https://" }
		if (devType == "SMART.IPCAMERA" || devType == "SMART.TAPODOORBELL" 
		    || devType == "SMART.TAPOHUB" || devType == "SMART.KASAHUB") {
			port = "443"
		} else if (devType == "SMART.TAPOROBOVAC" && protocol == "AES") {
			httpPath = ""
		}
		String baseUrl = httpStr + devIp + ":" + port + httpPath
		devData << [type: devType, model: model, baseUrl: baseUrl, dni: dni, ip: 
					devIp, port: port, protocol: protocol, status: "OK"]
		if (payload.power) { devData << [power: payload.power] }
		logDebug(devData)
	}
	return devData
}

def stringCorrect(payloadString) {
	//	Correct partial return from UDP message so it is JsonSlurper compatible.
	payloadString = payloadString.substring(0, payloadString.lastIndexOf("}"))
	def openCount = payloadString.count("{")
	def closeCount = payloadString.count("}")
	addString = "}" * (1 + openCount - closeCount)
	payloadString = payloadString + addString
	return payloadString
}
def isTypeSup(devType) {
	//	Validated device types
	List supTypes = ["SMART.TAPOBULB", "SMART.TAPOPLUG", "SMART.TAPOSWITCH", "SMART.KASAPLUG",
					 "SMART.KASASWITCH", "SMART.KASABULB",
					 //	Not currently implemented in code or by TP-Link
//					 "SMART.TAPOHUB", "SMART.KASAHUB", "SMART.TAPOROBOVAC", "SMART.IPCAMERA", 
//					 "SMART.TAPODOORBELL", "SMART.MATTERBULB", "SMART.MATTERPLUG"
	]
	def supported = false
	if (supTypes.contains(devType)) { supported = true }
	return supported
}

def getAllTpLinkDeviceData(List discData) {
	Map logData = [method: "getAllTpLinkDeviceData", discData: discData.size()]
	discData.each { Map devData ->
		if (devData.protocol == "KLAP") {
			klapHandshake(devData.baseUrl, localHash, devData)
		} else if (devData.protocol == "AES") {
			aesHandshake(devData.baseUrl, devData)
		} else { 
			unknownProt(devData)
		}
		pauseExecution(500)
	}
	atomicState.finding = false
	logDebug(logData)
}

def getDataCmd() {
	List requests = [[method: "get_device_info"]]
	requests << [method: "component_nego"]
	Map cmdBody = [
		method: "multipleRequest",
		params: [requests: requests]]
	return cmdBody
}

def addToDevices(devData, cmdData) {
	String dni = devData.dni
	Map devicesData = atomicState.devices
	devicesData.remove(dni)
	String tpType = devData.type
	String model = devData.model
	String alias
	comps = cmdData.find { it.method == "component_nego" }
	comps = comps.result.component_list
	cmdResp = cmdData.find { it.method == "get_device_info" }
	cmdResp = cmdResp.result
	byte[] plainBytes = cmdResp.nickname.decodeBase64()
	alias = new String(plainBytes)
	if (alias == "") { alias = model }
	def type = "Unknown"
	def ctHigh
	def ctLow
	Map deviceData = [devIp: devData.ip, deviceType: tpType, protocol: devData.protocol,
					  model: model, baseUrl: devData.baseUrl, alias: alias]
	//	Determine Driver to Load
	if (tpType.contains("PLUG") || tpType.contains("SWITCH")) {
		type = "Plug"
		if (comps.find { it.id == "control_child" }) {
			type = "Parent"
		} else if (comps.find{it.id=="dimmer"} || comps.find{it.id=="brightness"}) {
			type = "Dimmer"
		}
	} else if (tpType.contains("BULB")) {
		type = "Dimmer"
		if (comps.find { it.id == "light_strip" }) {
			type = "Lightstrip"
		} else if (comps.find { it.id == "color" }) {
			type = "Color Bulb"
		}
		if (type != "Dimmer" && comps.find { it.id == "color_temperature" } ) {
			deviceData << [ctHigh: cmdResp.color_temp_range[1], ctLow: cmdResp.color_temp_range[0]]
		}
	}
	
	deviceData << [type: type]
	if (comps.find {it.id == "led"} ) { 
		String ledVer = comps.find {it.id == "led"}.ver_code
		if (ledVer == null) {
			ledVer = comps.find { it.name == "led" }.version
		}
		deviceData << [ledVer: ledVer]
	}
	if (comps.find {it.id == "energy_monitoring"}) { deviceData << [isEm: "true"] }
	if (comps.find {it.id == "on_off_gradually"}) { deviceData << [gradOnOff: "true"] }
	devicesData << ["${dni}": deviceData]
	atomicState.devices = devicesData
	Map logData = [addToDevices: ["${deviceData.alias}", deviceData.model]]
	logInfo(logData)
	updateChild(dni, deviceData)
}

def updateChild(dni, deviceData) {
	def child = getChildDevice(dni)
	if (child) {
		child.updateChild(deviceData)
	}
}

//	===== get Smart KLAP Protocol Data =====
def sendKlapDataCmd(handshakeData, data) {
	if (handshakeData.respStatus != "Login OK") {
		Map logData = [method: "sendKlapDataCmd", handshake: handshakeData, data: data]
		logWarn(logData)
	} else {
		Map reqParams = [timeout: 10, headers: ["Cookie": data.data.cookie]]
		def seqNo = data.data.seqNo + 1
		String cmdBodyJson = new groovy.json.JsonBuilder(getDataCmd()).toString()
		Map encryptedData = klapEncrypt(cmdBodyJson.getBytes(), data.data.encKey, 
										data.data.encIv, data.data.encSig, seqNo)
		reqParams << [
			uri: "${data.data.devData.baseUrl}/request?seq=${encryptedData.seqNumber}",
			body: encryptedData.cipherData,
			ignoreSSLIssues: true,
			timeout:10,
			contentType: "application/octet-stream",
			requestContentType: "application/octet-stream"]
		asynchttpPost("parseKlapResp", reqParams, [data: data])
	}
}

def parseKlapResp(resp, respData) {
	Map data = respData.data
	Map logData = [method: "parseKlapResp", ip: data.data.devData.ip, model: data.data.devData.model]
	if (resp.status == 200) {
		Map cmdResp = [:]
		try {
			byte[] cipherResponse = resp.data.decodeBase64()[32..-1]
			def clearResp = klapDecrypt(cipherResponse, data.data.encKey,
									data.data.encIv, data.data.seqNo + 1)
			cmdResp =  new JsonSlurper().parseText(clearResp)
			logData << [status: "OK"]
		} catch (err) {
			logData << [error: err, errTxt: "error decyphering response"]
			logWarn(logData)
			return
		}
		if (cmdResp.error_code == 0) {
			addToDevices(data.data.devData, cmdResp.result.responses)
			logDebug(logData)
		} else {
			logData << [status: "errorInCmdResp", cmdResp: cmdResp]
			logWarn(logData)
		}
	} else {
		logData << [status: "httpFailure", data: resp.properties]
		logWarn(logData)
	}
}

//	===== get Smart AES Protocol Data =====
def getAesToken(resp, data) {
	Map logData = [method: "getAesToken"]
	if (resp.status == 200) {
		if (resp.json.error_code == 0) {
			try {
				def clearResp = aesDecrypt(resp.json.result.response, data.encKey, data.encIv)
				Map cmdResp = new JsonSlurper().parseText(clearResp)
				if (cmdResp.error_code == 0) {
					def token = cmdResp.result.token
					logData << [respStatus: "OK", token: token]
					logDebug(logData)
					sendAesDataCmd(token, data)
				} else {
					logData << [respStatus: "ERROR code in cmdResp", 
								error_code: cmdResp.error_code,
								check: "cryptoArray, credentials", data: cmdResp]
					logWarn(logData)
				}
			} catch (err) {
				logData << [respStatus: "ERROR parsing respJson", respJson: resp.json,
							error: err]
				logWarn(logData)
			}
		} else {
			logData << [respStatus: "ERROR code in resp.json", errorCode: resp.json.error_code,
						respJson: resp.json]
			logWarn(logData)
		}
	} else {
		logData << [respStatus: "ERROR in HTTP response", respStatus: resp.status, data: resp.properties]
		logWarn(logData)
	}
}

def sendAesDataCmd(token, data) {
	def cmdStr = JsonOutput.toJson(getDataCmd()).toString()
	Map reqBody = [method: "securePassthrough",
				   params: [request: aesEncrypt(cmdStr, data.encKey, data.encIv)]]
	Map reqParams = [uri: "${data.baseUrl}?token=${token}",
					 body: new groovy.json.JsonBuilder(reqBody).toString(),
					 contentType: "application/json",
					 requestContentType: "application/json",
					 timeout: 10,
					 headers: ["Cookie": data.cookie]]
	asynchttpPost("parseAesResp", reqParams, [data: data])
}

def parseAesResp(resp, data) {
	Map logData = [method: "parseAesResp"]
	if (resp.status == 200) {
		try {
			Map cmdResp = new JsonSlurper().parseText(aesDecrypt(resp.json.result.response,
																 data.data.encKey, data.data.encIv))
			logData << [status: "OK", cmdResp: cmdResp]
			if (cmdResp.error_code == 0) {
				addToDevices(data.data.devData, cmdResp.result.responses)
				logDebug(logData)
			} else {
				logData << [status: "errorInCmdResp"]
				logWarn(logData)
			}
		} catch (err) {
			logData << [status: "deviceDataParseError", error: err, dataLength: resp.data.length()]
			logWarn(logData)
		}
	} else {
		logData << [status: "httpFailure", data: resp.properties]
		logWarn(logData)
	}
}

//	===== Support device data update request =====
def tpLinkCheckForDevices(timeout = 5) {
	Map logData = [method: "tpLinkCheckForDevices"]
	def checked = true
	if (state.tpLinkChecked == true) {
		checked = false
		logData << [status: "noCheck", reason: "Completed within last 10 minutes"]
	} else {
		def findData = findTpLinkDevices("parseTpLinkCheck", timeout)
		logData << [status: "checking"]
		pauseExecution((timeout+2)*1000)
	}
	logDebug(logData)
	return checked
}

def resetTpLinkChecked() { state.tpLinkChecked = false }

def parseTpLinkCheck(response) {
	List discData = []
	if (response instanceof Map) {
		Map devdata = getDiscData(response)
		if (devData.status != "INVALID") {
			discData << devData
		}
	} else {
		response.each {
			Map devData = getDiscData(it)
			if (devData.status == "OK") {
				discData << devData
			}
		}
	}
	updateTpLinkDevices(discData)
}

def updateTpLinkDevices(discData) {
	Map logData = [method: "updateTpLinkDevices"]
	state.tpLinkChecked = true
	runIn(570, resetTpLinkChecked)
	List children = getChildDevices()
	children.each { childDev ->
		Map childData = [:]
		def dni = childDev.deviceNetworkId
		def connected = "false"
		Map devData = discData.find{ it.dni == dni }
		if (childDev.getDataValue("baseUrl")) {
			if (devData != null) {
				if (childDev.getDataValue("baseUrl") == devData.baseUrl &&
				    childDev.getDataValue("protocol") == devData.protocol) {
					childData << [status: "noChanges"]
				} else {
					childDev.updateDataValue("baseUrl", devData.baseUrl)
					childDev.updateDataValue("protocol", devData.protocol)
					childData << ["baseUrl": devData.baseUrl,
								  "protocol": devData.protocol,
								  "connected": "true"]
				}
			}
			pauseExecution(500)
		}
		logData << ["${childDev}": childData]
	}
	logDebug(logData)
}
