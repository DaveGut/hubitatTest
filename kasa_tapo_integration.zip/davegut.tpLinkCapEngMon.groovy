library (
	name: "tpLinkCapEngMon",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Hubitat Energy Monitor methods",
	category: "utilities",
	documentationLink: ""
)

capability "EnergyMeter"
capability "PowerMeter"
attribute "past30Energy", "number"
attribute "past7Energy", "number"
	
def emUpdated() {
	Map logData = [emDataUpdate: "30 mins"]
	runEvery30Minutes(getEmData)
	getEmData()
	return logData
}

def powerPoll() {
	List requests = [[method: "get_current_power"]]
	sendDevCmd(requests, "powerPoll", "parseUpdates")
}
	
def parse_get_current_power(result, data) {
	Map logData = [method: "parse_get_current_power", data: data,
				   power: result.current_power]
	updateAttr("power", result.current_power)
	logDebug(logData)
}

def getEmData() {
	List requests = [[method: "get_device_usage"]]
	sendDevCmd(requests, "getEmData", "parseUpdates")
}

def parse_get_device_usage(result, data) {
	Map logData = [method: "parse_get_device_usage", data: data]
	def usage = result.power_usage
	updateAttr("energy", usage.today)
	updateAttr("past30Energy", usage.past30)
	updateAttr("past7Energy", usage.past7)
	logData << [energy:usage.today, past30Energy: usage.past30, past7Energy: usage.past7]
	logDebug(logData)
}
