library (
	name: "appIotProt",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Discovery library for Application support the Kasa IOT protocol devices.",
	category: "utilities",
	documentationLink: ""
)

def getIotLanData(response) {
	logInfo([getIotLanData: [action: "Completed IOT LAN Discovery", devicesFound: response.size()]])
	if (response instanceof Map) {
		def lanData = parseIotLanData(response)
		if (lanData.error) { return }
		def cmdResp = lanData.cmdResp
		if (cmdResp.system) {
			cmdResp = cmdResp.system
		}
		def await = parseIotDeviceData(cmdResp, lanData.ip)
	} else {
		devices = state.devices
		response.each {
			def lanData = parseIotLanData(it)
			if (lanData.error) { return }
			def cmdResp = lanData.cmdResp
			if (cmdResp.system) {
				cmdResp = cmdResp.system
			}
			def await = parseIotDeviceData(cmdResp, lanData.ip)
		}
	}
}

def parseIotLanData(response) {
	def resp = parseLanMessage(response.description)
	if (resp.type == "LAN_TYPE_UDPCLIENT") {
		def ip = convertHexToIP(resp.ip)
		def port = convertHexToInt(resp.port)
		def clearResp = inputXOR(resp.payload)
		def cmdResp
		try {
			cmdResp = new JsonSlurper().parseText(clearResp).system.get_sysinfo
		} catch (err) {
			if (clearResp.contains("child_num")) {
				clearResp = clearResp.substring(0,clearResp.indexOf("child_num")-2) + "}}}"
			} else if (clearResp.contains("children")) {
				clearResp = clearResp.substring(0,clearResp.indexOf("children")-2) + "}}}"
			} else if (clearResp.contains("preferred")) {
				clearResp = clearResp.substring(0,clearResp.indexOf("preferred")-2) + "}}}"
			} else {
				logWarn("parseLanData: [error: msg too long, data: ${clearResp}]")
				return [error: "error", reason: "message to long"]
			}
			cmdResp = new JsonSlurper().parseText(clearResp).system.get_sysinfo
		}
		return [cmdResp: cmdResp, ip: ip, port: port]
	} else {
		return [error: "error", reason: "not LAN_TYPE_UDPCLIENT", respType: resp.type]
	}
}

def parseIotDeviceData(cmdResp, ip) {
	def dni
	if (cmdResp.mic_mac) {
		dni = cmdResp.mic_mac
	} else {
		dni = cmdResp.mac.replace(/:/, "")
	}
	Map devicesData = atomicState.devices
	def kasaType
	if (cmdResp.mic_type) {
		kasaType = cmdResp.mic_type
	} else {
		kasaType = cmdResp.type
	}
	def type = "Kasa Plug Switch"
	def feature = cmdResp.feature
	if (kasaType == "IOT.SMARTPLUGSWITCH") {
		if (cmdResp.dev_name && cmdResp.dev_name.contains("Dimmer")) {
			feature = "dimmingSwitch"
			type = "Kasa Dimming Switch"
		}
	} else if (kasaType == "IOT.SMARTBULB") {
		if (cmdResp.lighting_effect_state) {
			feature = "lightStrip"
			type = "Kasa Light Strip"
		} else if (cmdResp.is_color == 1) {
			feature = "colorBulb"
			type = "Kasa Color Bulb"
		} else if (cmdResp.is_variable_color_temp == 1) {
			feature = "colorTempBulb"
			type = "Kasa CT Bulb"
		} else {
			feature = "monoBulb"
			type = "Kasa Mono Bulb"
		}
	} else {
		logInfo([parseIotDeviceData:[notSupported:[
			"${cmdResp.model}":[type:kasaType, ip:ip, protocol:"IOT"]]]])
		return
	}
	if (cmdResp.children) {
		cmdResp.children.each {
			String childAlias = it.alias
			String plugNo = it.id
			String plugId = cmdResp.deviceId + plugNo
			String childDni = dni + plugNo
			Map device = [devIp: ip, protocol: "IOT", baseUrl: "${ip}:9999",
						  model: cmdResp.model.substring(0,5), kasaType: kasaType,
						  type: type, feature: feature, alias: childAlias, 
						  plugId: plugId, plugNo: plugNo]
			devicesData << ["${childDni}": device]
			logInfo([parseIotDeviceData: [ "${childAlias}": cmdResp.model]])
			updateChild(childDni, device)
		}
	} else {
		Map device = [devIp: ip, protocol: "IOT", baseUrl: "${ip}:9999",
					  model: cmdResp.model.substring(0,5), kasaType: kasaType,
					  type: type, feature: feature, alias: cmdResp.alias]
		devicesData << ["${dni}": device]
		logInfo([parseIotDeviceData: [ "${cmdResp.alias}": cmdResp.model]])
		updateChild(dni, device)
	}
	atomicState.devices = devicesData
	return
}



//	===== Support device data update request =====
def iotCheckForDevices(timeout = 5) {
	Map logData = [method: "iotCheckForDevices"]
	def checked = true
	if (state.iotChecked == true) {
		checked = false
		logData << [status: "noCheck", reason: "Completed within last 10 minutes"]
	} else {
		def findData = findTpLinkDevices("parseIotLanData", timeout)
		logData << [status: "checking"]
		pauseExecution((timeout+2)*1000)
	}
	state.iotChecked = true
	runIn(600, resetIotChecked)
	logDebug(logData)
logTrace(logData)
	return checked
}

def resetIotChecked() { state.iotChecked = false }



//////////////
def xxxxxxparseIotCheck(response) {
	List discData = []
	if (response instanceof Map) {
		Map devdata = getIotDiscData(response)
		if (devData.status != "INVALID") {
			discData << devData
		}
	} else {
		response.each {
			Map devData = getSmartDiscData(it)
			if (devData.status == "OK") {
				discData << devData
			}
		}
	}
	updateSmartDevices(discData)
}
//////////////////
def xxxxupdateSmartDevices(discData) {
	Map logData = [method: "updateSmartDevices"]
	state.smartChecked = true
	runIn(600, resetSmartChecked)
	List children = getChildDevices()
	children.each { childDev ->
		def dni = childDev.deviceNetworkId
		def connected = "false"
		Map devData = discData.find{ it.dni == dni }
		if (childDev.getDataValue("baseUrl")) {
			updateChild(dni, devData)
			pauseExecution(500)
		}
		logData << ["${childDev}": childData]
	}
	logDebug(logData)
}
//////////////////////////////
def xxxxupdateConfigurations() {
	Map logData = [method: "updateConfiguration", configureEnabled: configureEnabled]
	if (configureEnabled) {
		app?.updateSetting("configureEnabled", [type:"bool", value: false])
		configureChildren()
		runIn(600, configureEnable)
		logData << [status: "executing configureChildren"]
	} else {
		logData << [status: "notRun", data: "method rn with past 10 minutes"]
	}
	logInfo(logData)
	return logData
}
///////////////////////////
def xxxxconfigureEnable() {
	logDebug("configureEnable: Enabling configureDevices")
	app?.updateSetting("configureEnabled", [type:"bool", value: true])
}
//////////////////////////////////////////////
def xxxxxxxxconfigureChildren() {
	state.devices = [:]
	def await = findDevices(5)
	runIn(2, updateChildren)
}
//////////////////////////////
def xxxxxxxxupdateSmartDevices(discData) {
	Map logData = [method: "updateSmartDevices"]
	state.smartChecked = true
	runIn(600, resetSmartChecked)
	List children = getChildDevices()
	children.each { childDev ->
		def dni = childDev.deviceNetworkId
		def connected = "false"
		Map devData = discData.find{ it.dni == dni }
		if (childDev.getDataValue("baseUrl")) {
			updateChild(dni, devData)
			pauseExecution(500)
		}
		logData << ["${childDev}": childData]
	}
	logDebug(logData)
}
/////////////////////////
def xxxxxxxupdateChildren() {
	Map logData = [method: "updateChildren"]
	def children = getChildDevices()
	def devices = state.devices
	children.each { childDev ->
		Map childData = [:]
		def device = devices.find { it.value.dni == childDev.getDeviceNetworkId() }
		if (device == null) {
			logData << [error: "Child device not found in local database", 
						action:  "remove device or resolve LAN issue",
						note: "See integration documentation."]
			logWarn(logData)
		} else {
			childDev.updateAttr("commsError", "false")
			childData << [commsError: "false"]
/*			if (childDev.getDataValue("deviceIP") != device.value.ip ||
				childDev.getDataValue("devicePort") != device.value.port.toString()) {
				childDev.updateDataValue("deviceIP", device.value.ip)
				childDev.updateSetting("manualIp", [type:"string", value: device.value.ip])
				childDev.updateDataValue("devicePort", device.value.port.toString())
				childDev.updateSetting("manualPort", [type:"string", value: device.value.port.toString()])
				childData << [ip: device.value.ip, port: device.value.port]
			}*/
		}
		logData << ["${childDev}": childData]
	}
	logInfo(logData)
	return
}
////////////////////////////////////



def syncBulbPresets(bulbPresets) {
	logDebug("syncBulbPresets")
	def devices = state.devices
	devices.each {
		def type = it.value.type
		if (type == "Kasa Color Bulb" || type == "Kasa Light Strip") {
			def child = getChildDevice(it.value.dni)
			if (child) {
				child.updatePresets(bulbPresets)
			}
		}
	}
}

def resetStates(deviceNetworkId) {
	logDebug("resetStates: ${deviceNetworkId}")
	def devices = state.devices
	devices.each {
		def type = it.value.type
		def dni = it.value.dni
		if (type == "Kasa Light Strip") {
			def child = getChildDevice(dni)
			if (child && dni != deviceNetworkId) {
				child.resetStates()
			}
		}
	}
}

def syncEffectPreset(effData, deviceNetworkId) {
	logDebug("syncEffectPreset: ${effData.name} || ${deviceNetworkId}")
	def devices = state.devices
	devices.each {
		def type = it.value.type
		def dni = it.value.dni
		if (type == "Kasa Light Strip") {
			def child = getChildDevice(dni)
			if (child && dni != deviceNetworkId) {
				child.updateEffectPreset(effData)
			}
		}
	}
}

def coordinate(cType, coordData, deviceId, plugNo) {
	logDebug("coordinate: ${cType}, ${coordData}, ${deviceId}, ${plugNo}")
	def plugs = state.devices.findAll{ it.value.deviceId == deviceId }
	plugs.each {
		if (it.value.plugNo != plugNo) {
			def child = getChildDevice(it.value.dni)
			if (child) {
				child.coordUpdate(cType, coordData)
				pauseExecution(200)
			}
		}
	}
}

private outputXOR(command) {
	def str = ""
	def encrCmd = ""
 	def key = 0xAB
	for (int i = 0; i < command.length(); i++) {
		str = (command.charAt(i) as byte) ^ key
		key = str
		encrCmd += Integer.toHexString(str)
	}
   	return encrCmd
}

private inputXOR(encrResponse) {
	String[] strBytes = encrResponse.split("(?<=\\G.{2})")
	def cmdResponse = ""
	def key = 0xAB
	def nextKey
	byte[] XORtemp
	for(int i = 0; i < strBytes.length-1; i++) {
		nextKey = (byte)Integer.parseInt(strBytes[i], 16)	// could be negative
		XORtemp = nextKey ^ key
		key = nextKey
		cmdResponse += new String(XORtemp)
	}
	return cmdResponse
}

private String convertHexToIP(hex) {
	[convertHexToInt(hex[0..1]),convertHexToInt(hex[2..3]),convertHexToInt(hex[4..5]),convertHexToInt(hex[6..7])].join(".")
}

private Integer convertHexToInt(hex) { Integer.parseInt(hex,16) }
