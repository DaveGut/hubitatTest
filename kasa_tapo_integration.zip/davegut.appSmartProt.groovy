library (
	name: "appSmartProt",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Discovery library for Application support the Tapo Smart protocol devices.",
	category: "utilities",
	documentationLink: ""
)
import groovy.json.JsonOutput

def createSmartCreds() {
	Map SMARTCredData = [u: userName, p: userPassword]
	//	User Creds (username/password hashed)
	String encUsername = mdEncode("SHA-1", userName.bytes).encodeHex().encodeAsBase64().toString()
	app?.updateSetting("encUsername", [type: "string", value: encUsername])
	SMARTCredData << [encUsername: encUsername]
	String encPassword = userPassword.trim().bytes.encodeBase64().toString()
	app?.updateSetting("encPassword", [type: "string", value: encPassword])
	SMARTCredData << [encPassword: encPassword]
	//	KLAP Local Hash
	byte[] userHashByte = mdEncode("SHA-1", encodeUtf8(userName).getBytes())
	byte[] passwordHashByte = mdEncode("SHA-1", encodeUtf8(userPassword.trim()).getBytes())
	byte[] authHashByte = [userHashByte, passwordHashByte].flatten()
	String authHash = mdEncode("SHA-256", authHashByte).encodeBase64().toString()
	app?.updateSetting("localHash", [type: "string", value: authHash])
	SMARTCredData << [localHash: localHash]
	logDebug(SMARTCredData)
	return
}

def getSmartLanData(response) {
	logInfo([getSmartLanData: [action: "Completed SMART LAN Discovery", devicesFound: response.size()]])
	unschedule("udpTimeout")
	List discData = []
	if (response instanceof Map) {
		Map devData = getSmartDiscData(response)
		if (devData.status == "OK") {
			discData << devData
		}
	} else {
		response.each {
			Map devData = getSmartDiscData(it)
			if (devData.status == "OK" && !discData.toString().contains(devData.dni)) {
				discData << devData
			}
		}
	}
	getSmartDeviceData(discData)
}
def getSmartDiscData(response) {
	Map devData = [:]
	Map payload = [:]
	try {
		def respData = parseLanMessage(response.description)
		if (respData.type == "LAN_TYPE_UDPCLIENT") {
			byte[] payloadByte = hubitat.helper.HexUtils.hexStringToByteArray(respData.payload.drop(32)) 
			String payloadString = new String(payloadByte)
			if (payloadString.length() > 1007) {
				payloadString = smartStringCorrect(payloadString)
			}
			payload = new JsonSlurper().parseText(payloadString).result
		}
	} catch (err) {
		devData << [status: "INVALID", respData: repsData, error: err]
		logWarn(devData)
		return devData
	}
	String devType = payload.device_type
	String model = payload.device_model
	String devIp = payload.ip
	String protocol = payload.mgt_encrypt_schm.encrypt_type
	if (isTypeSup(devType) == false) {
		Map unsupData = ["<b>${model}</b>": [type: devType, ip: devIp, protocol: protocol]]
		logInfo([getSmartDiscData: [notSupported: unsupData]])
		atomicState.unsupported << ["<b>${model}</b>": [ip: ip, protocol: protocol]]
	} else {
		String dni = payload.mac.replaceAll("-", "")
		String port = payload.mgt_encrypt_schm.http_port
		String httpStr = "http://"
		String httpPath = "/app"
		if (payload.mgt_encrypt_schm.is_support_https) { httpStr = "https://" }
		if (devType == "SMART.IPCAMERA" || devType == "SMART.TAPODOORBELL" 
		    || devType == "SMART.TAPOHUB" || devType == "SMART.KASAHUB") {
			port = "443"
		} else if (devType == "SMART.TAPOROBOVAC" && protocol == "AES") {
			httpPath = ""
		}
		String baseUrl = httpStr + devIp + ":" + port + httpPath
		devData << [type: devType, model: model, baseUrl: baseUrl, dni: dni, ip: 
					devIp, port: port, protocol: protocol, status: "OK"]
		if (payload.power) { devData << [power: payload.power] }
		logDebug(devData)
	}
	return devData
}
def smartStringCorrect(payloadString) {
	//	Correct partial return from UDP message so it is JsonSlurper compatible.
	payloadString = payloadString.substring(0, payloadString.lastIndexOf("}"))
	def openCount = payloadString.count("{")
	def closeCount = payloadString.count("}")
	addString = "}" * (1 + openCount - closeCount)
	payloadString = payloadString + addString
	return payloadString
}
def isTypeSup(devType) {
	//	Validated device types
	List supTypes = ["SMART.TAPOBULB", "SMART.TAPOPLUG", "SMART.TAPOSWITCH", "SMART.KASAPLUG",
					 "SMART.KASASWITCH", "SMART.KASABULB",
					 //	Not currently implemented in code or by TP-Link
//					 "SMART.TAPOHUB", "SMART.KASAHUB", "SMART.TAPOROBOVAC", "SMART.IPCAMERA", 
//					 "SMART.TAPODOORBELL", "SMART.MATTERBULB", "SMART.MATTERPLUG"
	]
	def supported = false
	if (supTypes.contains(devType)) { supported = true }
	return supported
}

def getSmartDeviceData(List discData) {
	Map logData = [method: "getSmartDeviceData", discData: discData.size()]
	discData.each { Map devData ->
		if (devData.protocol == "KLAP") {
			klapHandshake(devData.baseUrl, localHash, devData)
		} else if (devData.protocol == "AES") {
			aesHandshake(devData.baseUrl, devData)
		} else { 
			unknownProt(devData)
		}
		pauseExecution(500)
	}
	atomicState.finding = false
	logDebug(logData)
}

def getSmartDataCmd() {
	List requests = [[method: "get_device_info"], [method: "component_nego"]]
	Map cmdBody = [method: "multipleRequest", params: [requests: requests]]
	return cmdBody
}

def smartAddToDevices(devData, cmdData) {
	String dni = devData.dni
	Map devicesData = atomicState.devices
	String tpType = devData.type
	String model = devData.model
	String alias
	comps = cmdData.find { it.method == "component_nego" }
	comps = comps.result.component_list
	cmdResp = cmdData.find { it.method == "get_device_info" }
	cmdResp = cmdResp.result
	byte[] plainBytes = cmdResp.nickname.decodeBase64()
	alias = new String(plainBytes)
	if (alias == "") { alias = model }
	def type = "Unknown"
	def ctHigh
	def ctLow
	Map deviceData = [devIp: devData.ip, deviceType: tpType, protocol: devData.protocol,
					  model: model, baseUrl: devData.baseUrl, alias: alias]
	//	Determine Driver to Load
	if (tpType.contains("PLUG") || tpType.contains("SWITCH")) {
		type = "Plug"
		if (comps.find { it.id == "control_child" }) {
			type = "Parent"
		} else if (comps.find{it.id=="dimmer"} || comps.find{it.id=="brightness"}) {
			type = "Dimmer"
		}
	} else if (tpType.contains("BULB")) {
		type = "Dimmer"
		if (comps.find { it.id == "light_strip" }) {
			type = "Lightstrip"
		} else if (comps.find { it.id == "color" }) {
			type = "Color Bulb"
		}
		if (type != "Dimmer" && comps.find { it.id == "color_temperature" } ) {
			deviceData << [ctHigh: cmdResp.color_temp_range[1], ctLow: cmdResp.color_temp_range[0]]
		}
	}
	deviceData << [type: type]
	if (comps.find {it.id == "led"} ) { 
		String ledVer = comps.find {it.id == "led"}.ver_code
		if (ledVer == null) {
			ledVer = comps.find { it.name == "led" }.version
		}
		deviceData << [ledVer: ledVer]
	}
	if (comps.find {it.id == "energy_monitoring"}) { deviceData << [isEm: "true"] }
	if (comps.find {it.id == "on_off_gradually"}) { deviceData << [gradOnOff: "true"] }
	devicesData << ["${dni}": deviceData]
	atomicState.devices = devicesData
	Map logData = [smartAddToDevices: ["${deviceData.alias}", deviceData.model]]
	logInfo(logData)
	updateChild(dni, deviceData)
}

//	===== get Smart KLAP Protocol Data =====
def sendKlapDataCmd(handshakeData, data) {
	if (handshakeData.respStatus != "Login OK") {
		Map logData = [method: "sendKlapDataCmd", handshake: handshakeData, data: data]
		logWarn(logData)
	} else {
		Map reqParams = [timeout: 10, headers: ["Cookie": data.data.cookie]]
		def seqNo = data.data.seqNo + 1
		String cmdBodyJson = new groovy.json.JsonBuilder(getSmartDataCmd()).toString()
		Map encryptedData = klapEncrypt(cmdBodyJson.getBytes(), data.data.encKey, 
										data.data.encIv, data.data.encSig, seqNo)
		reqParams << [
			uri: "${data.data.devData.baseUrl}/request?seq=${encryptedData.seqNumber}",
			body: encryptedData.cipherData,
			ignoreSSLIssues: true,
			timeout:10,
			contentType: "application/octet-stream",
			requestContentType: "application/octet-stream"]
		asynchttpPost("parseKlapResp", reqParams, [data: data])
	}
}

def parseKlapResp(resp, respData) {
	Map data = respData.data
	Map logData = [method: "parseKlapResp", ip: data.data.devData.ip, model: data.data.devData.model]
	if (resp.status == 200) {
		Map cmdResp = [:]
		try {
			byte[] cipherResponse = resp.data.decodeBase64()[32..-1]
			def clearResp = klapDecrypt(cipherResponse, data.data.encKey,
									data.data.encIv, data.data.seqNo + 1)
			cmdResp =  new JsonSlurper().parseText(clearResp)
			logData << [status: "OK"]
		} catch (err) {
			logData << [error: err, errTxt: "error decyphering response"]
			logWarn(logData)
			return
		}
		if (cmdResp.error_code == 0) {
			smartAddToDevices(data.data.devData, cmdResp.result.responses)
			logDebug(logData)
		} else {
			logData << [status: "errorInCmdResp", cmdResp: cmdResp]
			logWarn(logData)
		}
	} else {
		logData << [status: "httpFailure", data: resp.properties]
		logWarn(logData)
	}
}

//	===== get Smart AES Protocol Data =====
def getAesToken(resp, data) {
	Map logData = [method: "getAesToken"]
	if (resp.status == 200) {
		if (resp.json.error_code == 0) {
			try {
				def clearResp = aesDecrypt(resp.json.result.response, data.encKey, data.encIv)
				Map cmdResp = new JsonSlurper().parseText(clearResp)
				if (cmdResp.error_code == 0) {
					def token = cmdResp.result.token
					logData << [respStatus: "OK", token: token]
					logDebug(logData)
					sendAesDataCmd(token, data)
				} else {
					logData << [respStatus: "ERROR code in cmdResp", 
								error_code: cmdResp.error_code,
								check: "cryptoArray, credentials", data: cmdResp]
					logWarn(logData)
				}
			} catch (err) {
				logData << [respStatus: "ERROR parsing respJson", respJson: resp.json,
							error: err]
				logWarn(logData)
			}
		} else {
			logData << [respStatus: "ERROR code in resp.json", errorCode: resp.json.error_code,
						respJson: resp.json]
			logWarn(logData)
		}
	} else {
		logData << [respStatus: "ERROR in HTTP response", respStatus: resp.status, data: resp.properties]
		logWarn(logData)
	}
}

def sendAesDataCmd(token, data) {
	def cmdStr = JsonOutput.toJson(getSmartDataCmd()).toString()
	Map reqBody = [method: "securePassthrough",
				   params: [request: aesEncrypt(cmdStr, data.encKey, data.encIv)]]
	Map reqParams = [uri: "${data.baseUrl}?token=${token}",
					 body: new groovy.json.JsonBuilder(reqBody).toString(),
					 contentType: "application/json",
					 requestContentType: "application/json",
					 timeout: 10,
					 headers: ["Cookie": data.cookie]]
	asynchttpPost("parseAesResp", reqParams, [data: data])
}

def parseAesResp(resp, data) {
	Map logData = [method: "parseAesResp"]
	if (resp.status == 200) {
		try {
			Map cmdResp = new JsonSlurper().parseText(aesDecrypt(resp.json.result.response,
																 data.data.encKey, data.data.encIv))
			logData << [status: "OK", cmdResp: cmdResp]
			if (cmdResp.error_code == 0) {
				smartAddToDevices(data.data.devData, cmdResp.result.responses)
				logDebug(logData)
			} else {
				logData << [status: "errorInCmdResp"]
				logWarn(logData)
			}
		} catch (err) {
			logData << [status: "deviceDataParseError", error: err, dataLength: resp.data.length()]
			logWarn(logData)
		}
	} else {
		logData << [status: "httpFailure", data: resp.properties]
		logWarn(logData)
	}
}

//	===== Support device data update request =====
def smartCheckForDevices(timeout = 5) {
	Map logData = [method: "smartCheckForDevices"]
	def checked = true
	if (state.smartChecked == true) {
		checked = false
		logData << [status: "noCheck", reason: "Completed within last 10 minutes"]
	} else {
		def findData = findTpLinkDevices("parseSmartCheck", timeout)
		logData << [status: "checking"]
		pauseExecution((timeout+2)*1000)
	}
	logDebug(logData)
	return checked
}

def resetSmartChecked() { state.smartChecked = false }

def parseSmartCheck(response) {
	List discData = []
	if (response instanceof Map) {
		Map devdata = getSmartDiscData(response)
		if (devData.status != "INVALID") {
			discData << devData
		}
	} else {
		response.each {
			Map devData = getSmartDiscData(it)
			if (devData.status == "OK") {
				discData << devData
			}
		}
	}
	updateSmartDevices(discData)
}

def updateSmartDevices(discData) {
	Map logData = [method: "updateSmartDevices"]
	state.smartChecked = true
	runIn(600, resetSmartChecked)
	List children = getChildDevices()
	children.each { childDev ->
		def dni = childDev.deviceNetworkId
		def connected = "false"
		Map devData = discData.find{ it.dni == dni }
		if (childDev.getDataValue("baseUrl")) {
			updateChild(dni, devData)
			pauseExecution(500)
		}
		logData << ["${childDev}": childData]
	}
	logDebug(logData)
}
